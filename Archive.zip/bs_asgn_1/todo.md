- create server -> python nodejs
reqs:
-  endpoint -> http://localhost/log
- last 10 lines would be shown on hitting above url 
- news lines being appended on page without refresh.